<!DOCTYPE html>
<html>
	<head>
	<title>Homepage</title>
	<link rel="stylesheet" href="css/style.css">
	</head>
	<body>
		<header id="header">
<!--Idk what is our logo so I added hello-->
			<a href="#" class="logo">Hello</a>
		
		</header>
			<section>
				<img src="images/landscape.png" id="landscape">
				<h2 id="text"><span>Children Language</span><br>Learning System</h2>
			
<!--For the # add next section-->			
				<a href="#" id="btn">Explore</a>
				
			</section>
			
			<div class="sec">
				<h2>About</h2>
				<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla pretium luctus nibh quis convallis. Nullam ut metus quis mi porta mollis. Vivamus auctor consequat fringilla. Mauris vestibulum, nisl non ultricies scelerisque, lacus leo volutpat turpis, vitae pretium dolor lorem et libero. Mauris lobortis orci eget libero posuere lacinia. Ut fringilla dui vitae metus sollicitudin sollicitudin. Maecenas suscipit erat non tempus hendrerit. Aliquam sollicitudin mauris lacus, eu mollis massa pretium dictum. Ut sollicitudin lacus id feugiat convallis. Etiam finibus sit amet eros in rutrum. Maecenas cursus, nibh nec fermentum lobortis, nunc nibh cursus ipsum, sit amet vulputate nulla risus id arcu. Sed bibendum ligula vitae magna sagittis blandit. In congue feugiat imperdiet.
			
<br>
Vivamus at sollicitudin leo. Maecenas venenatis neque neque, id lobortis lacus bibendum sed. Aenean ac sapien eget leo fringilla tincidunt vitae non purus. Quisque mattis convallis augue, vitae tristique odio. Donec quam leo, euismod ut congue ac, porta nec dui. Aenean fringilla lorem arcu. Quisque maximus lobortis metus.
<br>
<br>
Suspendisse scelerisque vel enim ac rutrum. Maecenas ac vestibulum ipsum. Suspendisse vel efficitur ex. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Sed vehicula venenatis sem, et dignissim erat pulvinar id. Quisque vitae cursus lectus. Pellentesque et lacus molestie, vulputate quam eu, dictum erat. Integer ornare bibendum velit, non mattis justo consectetur at.
<br>
<br>
Phasellus malesuada, felis pharetra venenatis varius, ipsum quam volutpat sem, ut rhoncus risus lectus ac ligula. Sed convallis pretium ornare. Nunc enim ipsum, tincidunt a diam a, iaculis varius magna. Sed imperdiet facilisis lectus eu dapibus. Suspendisse pretium auctor sagittis. Aliquam erat volutpat. Mauris eros odio, sodales in fringilla ac, efficitur vel purus. Curabitur tristique fringilla iaculis. Vestibulum blandit justo at ex placerat, ac sagittis justo pretium. Ut porttitor erat quis sollicitudin venenatis. Nullam laoreet, velit in porttitor rhoncus, elit ex lacinia sem, vel imperdiet elit metus rhoncus neque. Ut ac euismod tortor, non pulvinar sem.
<br>
<br>
Maecenas tincidunt augue non ornare pellentesque. Quisque fermentum facilisis libero, et ornare nulla euismod vitae. Donec egestas nulla sed augue tristique pulvinar. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Quisque auctor non orci quis pellentesque. Morbi eros nunc, pharetra at ex nec, fringilla efficitur sem. Donec pellentesque arcu ac mauris posuere, sit amet posuere neque dapibus</p>
			</div>
			
	</body>
</html>